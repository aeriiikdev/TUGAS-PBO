package tugaspertemuan6;

import java.util.Scanner;

public class Kalkulator {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            char ulang;
            
            do {
                // Input angka pertama
                System.out.print("Masukkan angka pertama: ");
                double angka1 = scanner.nextDouble();
                
                // Input operator
                System.out.print("Masukkan operator (+, -, *, /, %): ");
                char operator = scanner.next().charAt(0);
                
                // Input angka kedua
                System.out.print("Masukkan angka kedua: ");
                double angka2 = scanner.nextDouble();
                
                double hasil = 0;
                boolean operatorValid = true;
                
                // Proses operasi
                switch (operator) {
                    case '+' -> hasil = angka1 + angka2;
                    case '-' -> hasil = angka1 - angka2;
                    case '*' -> hasil = angka1 * angka2;
                    case '/' -> {
                        if (angka2 != 0) {
                            hasil = angka1 / angka2;
                        } else {
                            System.out.println("Error: Pembagian dengan nol!");
                            operatorValid = false;
                        }
                    }
                    case '%' -> {
                        if (angka2 != 0) {
                            hasil = angka1 % angka2;
                        } else {
                            System.out.println("Error: Modulo dengan nol!");
                            operatorValid = false;
                        }
                    }
                    default -> {
                        System.out.println("Operator tidak valid.");
                        operatorValid = false;
                    }
                }
                
                // Tampilkan hasil jika operator valid
                if (operatorValid) {
                    System.out.println("Hasil: " + hasil);
                }
                
                // Tanya ulang
                System.out.print("Apakah Anda ingin menghitung lagi? (y/n): ");
                ulang = scanner.next().charAt(0);
                
            } while (ulang == 'y' || ulang == 'Y');
            
            System.out.println("Terima kasih telah menggunakan kalkulator!");
        }
    }
}