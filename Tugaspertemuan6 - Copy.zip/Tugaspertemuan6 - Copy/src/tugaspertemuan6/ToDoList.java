package tugaspertemuan6;

import java.util.ArrayList;
import java.util.Scanner;

public class ToDoList {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            ArrayList<String> tasks = new ArrayList<>();
            int pilihan;
            
            do {
                // Tampilkan menu
                System.out.println("\n=== MENU TO-DO LIST ===");
                System.out.println("1. Tambah Tugas");
                System.out.println("2. Lihat Semua Tugas");
                System.out.println("3. Hapus Tugas");
                System.out.println("4. Keluar");
                System.out.print("Pilih menu: ");
                pilihan = scanner.nextInt();
                scanner.nextLine(); // Clear newline buffer
                
                switch (pilihan) {
                    case 1 -> {
                        System.out.print("Masukkan tugas baru: ");
                        String tugas = scanner.nextLine();
                        tasks.add(tugas);
                        System.out.println("Tugas berhasil ditambahkan!");
                    }
                        
                    case 2 -> {
                        System.out.println("\n=== DAFTAR TUGAS ===");
                        if (tasks.isEmpty()) {
                            System.out.println("Daftar tugas kosong.");
                        } else {
                            for (int i = 0; i < tasks.size(); i++) {
                                System.out.println((i + 1) + ". " + tasks.get(i));
                            }
                        }
                    }
                        
                    case 3 -> {
                        if (tasks.isEmpty()) {
                            System.out.println("Tidak ada tugas untuk dihapus.");
                            break;
                        }
                        
                        System.out.print("Masukkan nomor tugas yang ingin dihapus: ");
                        int index = scanner.nextInt();
                        if (index >= 1 && index <= tasks.size()) {
                            tasks.remove(index - 1);
                            System.out.println("Tugas berhasil dihapus.");
                        } else {
                            System.out.println("Nomor tugas tidak valid.");
                        }
                    }
                        
                    case 4 -> System.out.println("Terima kasih telah menggunakan To-Do List.");
                        
                    default -> System.out.println("Pilihan tidak valid.");
                }
            } while (pilihan != 4);
        }
    }
}