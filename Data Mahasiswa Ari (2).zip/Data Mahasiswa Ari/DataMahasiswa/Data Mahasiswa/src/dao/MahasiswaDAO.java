package dao;

import db.Koneksi;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Mahasiswa;

public class MahasiswaDAO {
    private final Connection conn;

    public MahasiswaDAO() {
        conn = Koneksi.getKoneksi();
        if (conn == null) {
            System.err.println("Gagal koneksi ke database di MahasiswaDAO");
        }
    }

    // Create (Insert)
    public void insert(Mahasiswa mhs) {
        String sql = "INSERT INTO mahasiswa(nim, nama, alamat, phone, prodi, jenis_kelamin) VALUES(?,?,?,?,?,?)";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, mhs.getNim());
            ps.setString(2, mhs.getNama());
            ps.setString(3, mhs.getAlamat());
            ps.setString(4, mhs.getPhone());
            ps.setString(5, mhs.getProdi());
            ps.setString(6, mhs.getJenis_kelamin());
            ps.executeUpdate();
            System.out.println("Insert data berhasil");
        } catch (SQLException e) {
            System.err.println("Error insert: " + e.getMessage());
        }
    }

    // Read (Select All)
    public List<Mahasiswa> getAll() {
        List<Mahasiswa> listMhs = new ArrayList<>();
        String sql = "SELECT * FROM mahasiswa";

        if (conn == null) {
            System.err.println("Koneksi null di getAll()");
            return listMhs;
        }

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Mahasiswa mhs = new Mahasiswa();
                mhs.setNim(rs.getString("nim"));
                mhs.setNama(rs.getString("nama"));
                mhs.setAlamat(rs.getString("alamat"));
                mhs.setPhone(rs.getString("phone"));
                mhs.setProdi(rs.getString("prodi"));
                mhs.setJenis_kelamin(rs.getString("jenis_kelamin"));

                listMhs.add(mhs);
            }

            System.out.println("Ambil semua data mahasiswa berhasil. Total: " + listMhs.size());
        } catch (SQLException e) {
            System.err.println("Error select all: " + e.getMessage());
        }

        return listMhs;
    }

    // Update
    public void update(Mahasiswa mhs) {
        String sql = "UPDATE mahasiswa SET nama=?, alamat=?, phone=?, prodi=?, jenis_kelamin=? WHERE nim=?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, mhs.getNama());
            ps.setString(2, mhs.getAlamat());
            ps.setString(3, mhs.getPhone());
            ps.setString(4, mhs.getProdi());
            ps.setString(5, mhs.getJenis_kelamin());
            ps.setString(6, mhs.getNim());
            ps.executeUpdate();
            System.out.println("Update data berhasil");
        } catch (SQLException e) {
            System.err.println("Error update: " + e.getMessage());
        }
    }

    // Delete
    public void delete(String nim) {
        String sql = "DELETE FROM mahasiswa WHERE nim=?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, nim);
            ps.executeUpdate();
            System.out.println("Delete data berhasil");
        } catch (SQLException e) {
            System.err.println("Error delete: " + e.getMessage());
        }
    }

    // Search by NIM
    public Mahasiswa getByNim(String nim) {
        Mahasiswa mhs = null;
        String sql = "SELECT * FROM mahasiswa WHERE nim=?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, nim);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                mhs = new Mahasiswa();
                mhs.setNim(rs.getString("nim"));
                mhs.setNama(rs.getString("nama"));
                mhs.setAlamat(rs.getString("alamat"));
                mhs.setPhone(rs.getString("phone"));
                mhs.setProdi(rs.getString("prodi"));
                mhs.setJenis_kelamin(rs.getString("jenis_kelamin"));
                System.out.println("Data ditemukan untuk NIM: " + nim);
            } else {
                System.out.println("Data tidak ditemukan untuk NIM: " + nim);
            }
        } catch (SQLException e) {
            System.err.println("Error search by NIM: " + e.getMessage());
        }

        return mhs;
    }
}
