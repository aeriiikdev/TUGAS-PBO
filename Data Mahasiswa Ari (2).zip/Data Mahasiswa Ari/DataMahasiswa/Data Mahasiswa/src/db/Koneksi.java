package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author LENOVO
 */
public class Koneksi {
    private static Connection conn;

    public static Connection getKoneksi() {
        if (conn == null) {
            try {
                String host = "jdbc:mysql://localhost:3306/data_mahasiswa"; // tambahkan port 3306
                String user = "root";
                String pass = "";

                conn = DriverManager.getConnection(host, user, pass);
                System.out.println("Koneksi ke database BERHASIL."); // untuk debug
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Koneksi Database Gagal: " + e.getMessage());
                System.err.println("Error detail: " + e.getMessage());
            }
        }
        return conn;
    }
}
